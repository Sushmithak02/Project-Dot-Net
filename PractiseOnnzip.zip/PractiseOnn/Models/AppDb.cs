﻿using Microsoft.EntityFrameworkCore;

namespace PractiseOnn.Models
{
    public class AppDb : DbContext
    {
        public AppDb(DbContextOptions<AppDb> options) : base(options) { }


        public DbSet<EmployeeDetails> EmployeeDetails { get; set; }
        public DbSet<UserDetails> UserDetails { get; set; } 

    }
}
