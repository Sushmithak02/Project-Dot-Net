﻿using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.IndexAttribute;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PractiseOnn.Models
{
    [Table("UserDetails")]
    public class UserDetails
    {
        [Key]
        //[Index(nameof(First_Name), IsUnique = true)]
        public int Id { get; set; }
        //[Required,First_Name]
        [RegularExpression("^[a-zA-Z]*$", ErrorMessage = "Only Alphabets")]
        public string First_Name { get; set; }
        [Required]
        [RegularExpression("^[a-zA-Z]*$", ErrorMessage = "Only Alphabets")]
        public string Last_Name { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public bool IsActive { get; set; }

    }
}
