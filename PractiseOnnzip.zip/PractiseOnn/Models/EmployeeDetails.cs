﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO.Compression;

namespace PractiseOnn.Models
{
    [Table("EmployeeDetails")]
    public class EmployeeDetails
    {
        [Key]
        public int Employee_ID { get; set; }
        [Required]
        [RegularExpression("^[a-zA-Z]*$",ErrorMessage ="Only Alphabets")]
        [MaxLength(50)]
        public string Employee_Name { get; set; }
        [Required]
        [MaxLength(200)]
        public string Employee_Address { get; set; }
        [Required]
        [RegularExpression("^[0-9]*$",ErrorMessage ="Only Numbers")]
        [MaxLength(13)]
        public string Employee_PhoneNumber { get; set; }
        [Required]
        [MaxLength (50)]
        public string Employee_Company { get; set; }
        [Required]
        public DateOnly Employee_JoiningDate { get; set; }
        [Required]
        [Range(1,50)]
        public int Employee_Experience { get; set; }
        [Required]
        [MaxLength(200)]
        public string Employee_Skill { get; set; }
        [Required]
        public DateOnly Employee_OffShoreStartdate { get; set; }
        [Required]
        public DateOnly Employee_OffShoreEnddate { get; set; }


    }
}
