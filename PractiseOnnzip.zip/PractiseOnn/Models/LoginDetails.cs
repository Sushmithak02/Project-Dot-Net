﻿namespace PractiseOnn.Models
{
    public class LoginDetails
    {
        public  string Email { get; set; }
        public string Password { get; set; }

    }
}
