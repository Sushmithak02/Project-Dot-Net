﻿using Microsoft.AspNetCore.Mvc;
using PractiseOnn.Models;
using System.Linq;

namespace PractiseOnn.Controllers
{
    public class LoginController : Controller
    {
        private readonly AppDb _db;

        public LoginController(AppDb db)
        {
            _db = db;
        }

        [HttpGet]
        public IActionResult LoginUser()
        {
            return View();
        }

        [HttpPost]
        public IActionResult LoginUser(LoginDetails obj)
        {
            if (!ModelState.IsValid)
            {
                return View(obj);
            }

            bool userExists = _db.UserDetails
                .Any(u => u.Email == obj.Email && u.Password == obj.Password);

            if (userExists)
            {
                TempData["res"] = "Login successful!";
                return RedirectToAction("AddEmployee", "Employee"); // Redirect to next page
            }
            else
            {
                TempData["res"] = "Invalid email or password!";
                return View(obj);
            }
        }

        [HttpGet]
        public IActionResult Logout()
        {
            TempData["res"] = "Logged out successfully.";
            return RedirectToAction("LoginUser");
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserDetails obj)
        {
            if (_db.UserDetails.Any(x => x.Email == obj.Email))
            {
                TempData["res"] = "Email already exists!";
                return View();
            }

            if (ModelState.IsValid)
            {
                _db.UserDetails.Add(obj);
                _db.SaveChanges();
                TempData["res"] = "User registered successfully!";
                return RedirectToAction("LoginUser");
            }

            TempData["res"] = "Error in registration!";
            return View(obj);
        }
    }
}
