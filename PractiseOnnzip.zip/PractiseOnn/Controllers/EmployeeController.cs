﻿using Microsoft.AspNetCore.Mvc;
using PractiseOnn.Models;
using PractiseOnn.Repos;

namespace PractiseOnn.Controllers
{
    public class EmployeeController : Controller
    {
        public readonly IEmployeeRepo _db;
        public EmployeeController(IEmployeeRepo db)
        {
            _db = db;
        }
        [HttpGet]
        public IActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddEmployee(EmployeeDetails obj)
        {
            if (ModelState.IsValid)
            {
                await _db.AddEmployee(obj);
                TempData["res"] = "Employee Added Succesfully";
                return RedirectToAction("GetEmployeeData");
            }
            else
            {
                TempData["res"] = "Error in adding user";
            }
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> GetEmployeeData()
        {
            var res = await _db.GetEmployeeList();
            return View(res);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int Id)
        {
            var res = await _db.GetEmployeebyId(Id);
            return View(res);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(EmployeeDetails obj)
        {
            var res = _db.UpdateEmployee(obj);
            return RedirectToAction("GetEmployeeData");
        }


        [HttpGet]
        public async Task<IActionResult> Delete(int Id)
        {
            var res = await _db.GetEmployeebyId(Id);
            return View(res);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirm(int Id)
        {
            var res = _db.DeleteEmployee(Id);
            return RedirectToAction("GetEmployeeData");
        }


        [HttpGet]
        public async Task<IActionResult> Details(int Id)
        {
            var res = await _db.GetEmployeebyId(Id);
            return View(res);
        }
    }
}
