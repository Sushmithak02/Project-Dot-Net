﻿using Microsoft.EntityFrameworkCore;
using PractiseOnn.Models;


namespace PractiseOnn.Repos
{
    public class EmployeeRepo : IEmployeeRepo
    {
        AppDb _db;
        public EmployeeRepo(AppDb db)
        {
            _db = db;
        }

        public async Task AddEmployee(EmployeeDetails obj)
        {
            if (obj != null)
            {
                await _db.AddAsync(obj);
                await _db.SaveChangesAsync();
            }
            else
            {
                throw new ArgumentNullException(nameof(obj),"Employee cannt be null");
            }
        }

        public async Task<EmployeeDetails> GetEmployeebyId(int id)
        {
            return await _db.EmployeeDetails.FirstOrDefaultAsync(x => x.Employee_ID == id);
        }

        public async Task<List<EmployeeDetails>> GetEmployeeList()
        {
            return await _db.EmployeeDetails.ToListAsync();
        }

        public async Task DeleteEmployee(int id)
        {
            var res = _db.EmployeeDetails.Find(id);
            if (res != null)
            {
                _db.Remove(res);
                await _db.SaveChangesAsync();
            }
        }

        public async Task UpdateEmployee(EmployeeDetails obj)
        {
            _db.EmployeeDetails.Update(obj);
            await _db.SaveChangesAsync();
        }

    }
}
