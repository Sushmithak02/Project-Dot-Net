﻿using PractiseOnn.Models;

namespace PractiseOnn.Repos
{
    public interface IEmployeeRepo
    {
        Task AddEmployee(EmployeeDetails obj);
        Task UpdateEmployee(EmployeeDetails obj);
        Task DeleteEmployee(int id);
        Task<EmployeeDetails> GetEmployeebyId(int id);
        Task<List<EmployeeDetails>> GetEmployeeList();
    }
}
