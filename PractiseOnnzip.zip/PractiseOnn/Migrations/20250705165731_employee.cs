﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PractiseOnn.Migrations
{
    /// <inheritdoc />
    public partial class employee : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EmployeeDetails",
                columns: table => new
                {
                    Employee_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Employee_Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Employee_Address = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Employee_PhoneNumber = table.Column<string>(type: "nvarchar(13)", maxLength: 13, nullable: false),
                    Employee_Company = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Employee_JoiningDate = table.Column<DateOnly>(type: "date", nullable: false),
                    Employee_Experience = table.Column<int>(type: "int", nullable: false),
                    Employee_Skill = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Employee_OffShoreStartdate = table.Column<DateOnly>(type: "date", nullable: false),
                    Employee_OffShoreEnddate = table.Column<DateOnly>(type: "date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeDetails", x => x.Employee_ID);
                });

            migrationBuilder.CreateTable(
                name: "UserDetails",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    First_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Last_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserDetails", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmployeeDetails");

            migrationBuilder.DropTable(
                name: "UserDetails");
        }
    }
}
