﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineBooksStore.Models;
using OnlineBooksStore.Repos;
using System.Net;

namespace OnlineBooksStore.Controllers
{
    public class BooksDataController : Controller
    {

        //For Books Entity
        private readonly Ibookrepo _bookRepository;
        public BooksDataController(Ibookrepo bookRepository)
        {
            _bookRepository = bookRepository;
        }
        // GET: Books
        public async Task<IActionResult> Index()
        {
            var books = await _bookRepository.GetAllBooksAsync();
            return View(books);
        }
        // GET: Books/Details/5
        public async Task<IActionResult> Details(int? BookID)
        {
            if (BookID == null)
            {
                return NotFound();
            }
            var books = await _bookRepository.GetBooksByIdAsync(Convert.ToInt32(BookID));
            if (books == null)
            {
                return NotFound();
            }
            return View(books);
        }
        // GET: Books/Create
        public IActionResult Create()
        {
            return View();
        }
        // POST: Books/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookID,BookName,Genre,Availabilitystatus")] BooksDetails books)
        {
            if (ModelState.IsValid)
            {
                await _bookRepository.InsertBooksAsync(books);
                //Call SaveAsync to Insert the data into the database
                await _bookRepository.SaveAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(books);
        }
        // GET: Books/Edit/5
        public async Task<IActionResult> Edit(int? BookID)
        {
            if (BookID == null)
            {
                return NotFound();
            }
            var books = await _bookRepository.GetBooksByIdAsync(Convert.ToInt32(BookID));
            if (books == null)
            {
                return NotFound();
            }
            return View(books);
        }
        // POST: Books/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int BookID, [Bind("BookID,BookName,Genre,Availabilitystatus")] BooksDetails books)
        {
            if (BookID != books.BookID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    await _bookRepository.UpdateBooksAsync(books);
                    await _bookRepository.SaveAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    var book = await _bookRepository.GetBooksByIdAsync(books.BookID);
                    if (book == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(books);
        }
        // GET: Employees/Delete/5
        public async Task<IActionResult> Delete(int? BookID)
        {
            if (BookID == null)
            {
                return NotFound();
            }
            var books = await _bookRepository.GetBooksByIdAsync(Convert.ToInt32(BookID));
            if (books == null)
            {
                return NotFound();
            }
            return View(books);
        }
        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int BookID)
        {
            var books = await _bookRepository.GetBooksByIdAsync(BookID);
            if (books != null)
            {
                await _bookRepository.DeleteAsync(BookID);
                await _bookRepository.SaveAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
