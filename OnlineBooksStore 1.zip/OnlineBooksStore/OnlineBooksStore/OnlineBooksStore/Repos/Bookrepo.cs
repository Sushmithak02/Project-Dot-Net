﻿using Microsoft.EntityFrameworkCore;
using OnlineBooksStore.Models;
using static OnlineBooksStore.Repos.Bookrepo;

namespace OnlineBooksStore.Repos
{
    public class Bookrepo : Ibookrepo
    {
        private readonly AppDatabaseContext _context;


        public Bookrepo(AppDatabaseContext context)
        {
            _context = context;
        }

        //Returns all books from the database.
        public async Task<IEnumerable<BooksDetails>> GetAllBooksAsync()
        {
            return await _context.Books.ToListAsync();
        }

        //Retrieves a single books by their ID.
        public async Task<BooksDetails?> GetBooksByIdAsync(int BookID)
        {
            var books = await _context.Books
               .FirstOrDefaultAsync(m => m.BookID == BookID);

            return books;
        }

        //Adds a new books to the database.
        public async Task InsertBooksAsync(BooksDetails books)
        {
            await _context.Books.AddAsync(books);
        }

        //Updates an existing books's details.
        public async Task UpdateBooksAsync(BooksDetails books)
        {
            _context.Books.Update(books);
        }

        //Deletes an books from the database
        public async Task DeleteAsync(int BookID)
        {
            var books = await _context.Books.FindAsync(BookID);
            if (books != null)
            {
                _context.Books.Remove(books);
            }
        }

        //InsertAsync, UpdateAsync, and DeleteAsync methods,
        //remember to call SaveAsync to commit the changes to the database.
        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
