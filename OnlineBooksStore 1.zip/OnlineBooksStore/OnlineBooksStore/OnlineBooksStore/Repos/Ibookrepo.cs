﻿using OnlineBooksStore.Models;

namespace OnlineBooksStore.Repos
{
    public interface Ibookrepo
    {
        Task<IEnumerable<BooksDetails>> GetAllBooksAsync();

        Task<BooksDetails?> GetBooksByIdAsync(int BookID);

    
        Task InsertBooksAsync(BooksDetails books);

        Task UpdateBooksAsync(BooksDetails books);

     
        Task DeleteAsync(int BookID);

    
        Task SaveAsync();
    }
}
