﻿using Microsoft.EntityFrameworkCore;

namespace OnlineBooksStore.Models
{
    public class AppDatabaseContext : DbContext
    {
        //Constructor calling the Base DbContext Class Constructor
        public AppDatabaseContext(DbContextOptions<AppDatabaseContext> options) : base(options)
        {
        }

        //Adding Domain Classes as DbSet Properties
        public DbSet<BooksDetails> Books { get; set; }
    }
}

