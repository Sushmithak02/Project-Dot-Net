﻿using Microsoft.AspNetCore.Mvc.Infrastructure;
using System.ComponentModel.DataAnnotations;

namespace OnlineBooksStore.Models
{
    public class BooksDetails
    {
        [Key]
        public int BookID { get; set; }

        [Required]
        public string? BookName { get; set; }
        [Required]
        public string? Genre { get; set; }

        public bool Availabilitystatus { get; set; }
    }
}
