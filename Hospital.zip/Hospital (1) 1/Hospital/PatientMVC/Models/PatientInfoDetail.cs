﻿using System.ComponentModel.DataAnnotations;

namespace PatientMVC.Models
{
    public class PatientInfoDetail
    {
        [Key]
        public int id { get; set; }
        [Required]
        public string patientName { get; set; }
        [Required]
        public int age { get; set; }
        [Required]
        public string gender { get; set; }
        public string bloodGroup { get; set; }
        [Required]
        public string contactNumber { get; set; }
        [Required]
        public string emailId { get; set; }
    }
}
