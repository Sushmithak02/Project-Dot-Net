﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using PatientDAL.Model;
using PatientDAL.Repository;

namespace PatientMVC.Controllers
{
    public class PatientController : Controller
    {
        private PatientRepo repo;
        public PatientController(PatientRepo repo)
        {
            this.repo = repo;
        }
        public IActionResult Index()
        {
            List<PatientInfoDetail> p = repo.getAll();
            return View(p);
        }
        //[HttpGet]
        //public IActionResult Display()
        //{
        //    var detail = repo.getAll();
        //    if (detail == null)
        //    {
        //        return NotFound();
        //    }
        //    return View(detail);
        //}

        public IActionResult registerForMembership()
        {
            return View();
        }
        [HttpPost]
        public IActionResult registerForMembership(Models.PatientInfoDetail pObj)
        {
            PatientInfoDetail pd = new PatientInfoDetail();
            pd.patientName = pObj.patientName;
            pd.age = pObj.age;
            pd.gender = pObj.gender;
            pd.bloodGroup = pObj.bloodGroup;
            pd.contactNumber = pObj.contactNumber;
            pd.emailId = pObj.emailId;

            if (ModelState.IsValid)
            {
                try
                {
                    repo.registerForMembership(pd);
                    return RedirectToAction("Index");
                }
                catch (Exception e)
                {
                    ModelState.AddModelError("", e.Message);
                }
            }
            return View(pObj);
        }
        public IActionResult cancelMembership(int id)
        {
            PatientInfoDetail pd = repo.getByRegistrationId(id);
            repo.cancelMembership(id);
            return View(pd);
        }
        [HttpPost]
        public IActionResult cancelMembership(PatientInfoDetail pObj)
        {
            return RedirectToAction("Index");
        }
        public IActionResult updateEmail(int id)
        {
            var user = repo.getByRegistrationId(id);
            if (id == null)
            {
                return NotFound("Details not found");
            }
            return View(user);
        }
        [HttpPost]
        public IActionResult updateEmail(PatientInfoDetail pObj)
        {
            repo.updateEmail(pObj);
            return RedirectToAction("Index");
        }
    }
}
