﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDAL.Model
{
    public class PatientInfoDetail
    {
        public int id { get; set; }
        public string patientName { get; set; }
        public int age { get; set; }
        public string gender { get; set; }
        public string bloodGroup { get; set; }
        public string contactNumber { get; set; }
        public string emailId { get; set; }
    }
}
