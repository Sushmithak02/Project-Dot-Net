﻿using PatientDAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDAL.Repository
{
    public interface IPatientRepo
    {
        public List<PatientInfoDetail> getAll();
        public bool registerForMembership(PatientInfoDetail pObj);
        public bool cancelMembership(int registrationId);
        public bool updateEmail(PatientInfoDetail pObj);
        public PatientInfoDetail getByRegistrationId(int registrationId);
    }
}
