﻿using PatientDAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDAL.Repository
{
    public class PatientRepo : IPatientRepo
    {
        private PatientContext context;
        public PatientRepo()
        {
            context=new PatientContext();
        }
        public bool cancelMembership(int id)
        {
            if (id == null)
            {
                return false;
            }
            PatientInfoDetail detail = new PatientInfoDetail(); 
            try
            {
                detail=context.Details.Find(id);
                if (detail != null)
                {
                    context.Details.Remove(detail);
                    context.SaveChanges();
                }
            }
            catch(Exception e)
            {
                return false;
            }
            return true;
        }

        public List<PatientInfoDetail> getAll()
        {
            return context.Details.ToList();
        }

        public PatientInfoDetail getByRegistrationId(int registrationId)
        {
            PatientInfoDetail p=context.Details.Where(x=>x.id== registrationId).FirstOrDefault();
            context.SaveChanges();
            return p;
        }

        public bool registerForMembership(PatientInfoDetail pObj)
        {
            context.Details.Add(pObj);
            context.SaveChanges();
            return true;
        }

        public bool updateEmail(PatientInfoDetail pass)
        {
            //PatientInfoDetail p=context.Details.Where(x=>x.id == registrationId).FirstOrDefault();
            //p.emailId = email;

            PatientInfoDetail p = context.Details.Find(pass.id);
            p.emailId = pass.emailId;
            //p.emailId = email;
            context.SaveChanges();
            return true;
        }
    }
}
